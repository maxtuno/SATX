"""
The SAT-X system is a CNF compiler and SAT solver built into Python.
"""

from .stdlib import *
