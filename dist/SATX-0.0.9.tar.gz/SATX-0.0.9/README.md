## SAT-X [![Downloads](https://pepy.tech/badge/satx)](https://pepy.tech/project/satx)

The SAT-X system is a CNF compiler and SAT solver built into Python.

## Installation
```python
pip install satx
```

Note: SAT-X is an experimental and under research extension of www.PEQNP.com work different, with support for negative numbers, modular arithmetics, and more...

Soon in www.sat-x.io, updates, tutorials, tips, news in general, about SAT-X.

<img
  src="https://cr-ss-service.azurewebsites.net/api/ScreenShot?widget=summary&username=maxtuno&badges=2&show-avatar=true&style=--header-bg-color:%23000;--border-radius:10px"/>
