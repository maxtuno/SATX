## SATX

The SATX its an automatic CNF compiler and interpreter integrated with Python.

## Installation
```python
pip install satx
```

Note: SATX is an experimental and under research extension of www.PEQNP.com work different, with support for negative numbers, modular arithmetics, and more...