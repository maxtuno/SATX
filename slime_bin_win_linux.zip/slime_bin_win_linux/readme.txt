slime -> Linux Static Compiled (chmod 777 slime)
slime.exe -> Windows x64 Static Compiled